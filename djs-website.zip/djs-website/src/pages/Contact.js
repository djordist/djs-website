export default function Contact() {
  return (
    <div>
      <h1>Contact</h1>
      <p>Wij zijn bereikbaar na 15:30 voor werken. Mijn vriend doet overdag de planning en communicatie.</p>
      <p>Email: info@djselektro.be</p>
      <p>Telefoon: 0470 00 00 00</p>
    </div>
  );
}