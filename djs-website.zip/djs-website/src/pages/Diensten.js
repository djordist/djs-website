export default function Diensten() {
  return (
    <div>
      <h1>Onze Diensten</h1>
      <ul>
        <li>Zekeringkasten vernieuwen</li>
        <li>Zonnepanelen plaatsen</li>
        <li>Laadpalen installeren</li>
        <li>Airco installatie</li>
        <li>Slijpen en draden trekken</li>
        <li>Nieuwbouw elektriciteitswerken</li>
      </ul>
    </div>
  );
}